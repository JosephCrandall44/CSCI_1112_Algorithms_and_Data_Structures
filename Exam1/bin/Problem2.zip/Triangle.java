
public class Triangle extends Shape {
	double base;
	double height;
}
