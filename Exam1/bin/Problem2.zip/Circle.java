
public class Circle extends Shape {
	double radius;

}
