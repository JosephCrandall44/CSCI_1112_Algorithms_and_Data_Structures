
public class Pyramid extends Triangle {
	double length;
	double volume;

}
