public class Rectangle extends Square {
	double height;
	
}
