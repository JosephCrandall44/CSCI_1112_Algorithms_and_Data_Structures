
public class Shape {
	double area;
	double perimeter;
}
