public class Square extends Shape{
	double width;
	double diagonal;
}

